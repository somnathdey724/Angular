import { Injectable } from '@angular/core';
import { HttpClient,HttpParams,HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, throwError, BehaviorSubject } from 'rxjs';
import { FormGroup } from '@angular/forms';
import {map,catchError} from 'rxjs/operators';
import { IfStmt } from '@angular/compiler';
import { Profile } from '../profile';
import { UserProfileComponent } from '../user-profile/user-profile.component';


@Injectable({
  providedIn: 'root'
})
export class CapBookService {
  profile:Profile;
  private userProfile=new BehaviorSubject(this.profile);
  currentProfile=this.userProfile.asObservable();
  changeProfile(profile:Profile){
    this.userProfile.next(profile);
  }
  constructor(private httpClient: HttpClient) { }

  public userRegistration(registrationForm:FormGroup):Observable<string>{
    let body = JSON.parse(JSON.stringify(registrationForm.value));
  
    return this.httpClient.post<string>("http://localhost:8085/registerUser",body).pipe(catchError(this.handleError));
 }
  
   public userLogin(loginForm:FormGroup):Observable<Profile>{
     let body=JSON.parse(JSON.stringify(loginForm.value));
     return this.httpClient.post<Profile>("http://localhost:8085/loginUser",body).pipe(catchError(this.handleError));     
  }
  public editProfile(editProfileForm:FormGroup):Observable<Profile>{
    let body=JSON.parse(JSON.stringify(editProfileForm.value));
    return this.httpClient.post<Profile>("http://localhost:8085/editProfile",body).pipe(catchError(this.handleError));     
 }
 public forgotPassword(forgetPasswordForm:FormGroup):Observable<string>{
  let body=JSON.parse(JSON.stringify(forgetPasswordForm.value));
  return this.httpClient.post<string>("http://localhost:8085/forgotPassword",body).pipe(catchError(this.handleError));     
}

public changePassword(newPassword:string):Observable<Profile>{
  let params = new HttpParams();
  console.log(newPassword);
  params=params.set('password',newPassword);
  let body=JSON.parse(JSON.stringify(newPassword));
  return this.httpClient.post<Profile>("http://localhost:8085/forgotPassword",{params:params}).pipe(catchError(this.handleError));     
}
 
  // error Handler
  private handleError(error: any){
    if(error instanceof ErrorEvent){
      console.error(`1 An ErrorEvent occurred: `,error.error.message);
      return throwError(error.error.message);
    }else if(error instanceof HttpErrorResponse){
      console.error(`2 Backend returned code ${error.status}, body was: ${error.message}`);
      return throwError(`Backend returned code ${error.status}, body was: ${error.message}`);
    }else if(error instanceof TypeError){
      console.error(`3 TypeError has occurred ${error.message}, body was: ${error.stack}`);
      return throwError(`TypeError has occurred ${error.message}, body was: ${error.stack}`);
    }
  }

  
}