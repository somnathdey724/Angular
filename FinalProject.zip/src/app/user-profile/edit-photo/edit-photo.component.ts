import { Component, OnInit } from '@angular/core';

@Component({
  template: ` 
  <div> 
    <h2>Data from EditPhotoComponent: {{ profile }} </h2> 
    <input [(ngModel)] = profile /> 
    <br><br> 
    <a [routerLink]="['/userProfile']">Go to UserLogin</a> 
  </div> 
  `,
  selector: 'app-edit-photo',
  templateUrl: './edit-photo.component.html',
  styleUrls: ['./edit-photo.component.css']
})
export class EditPhotoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
