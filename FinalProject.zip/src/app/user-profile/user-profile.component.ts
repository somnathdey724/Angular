import { Component, OnInit,OnChanges, Input } from '@angular/core';
import { Profile } from '../profile';
import { ActivatedRoute, Router } from '@angular/router';
import { CapBookService } from '../services/cap-book.service';

@Component({
/*   template: ` 
  <div> 
    <h2>Data from UserProfileComponent: {{ profile }} </h2> 
    <input [(ngModel)] = profile /> 
    <br><br> 
    <a [routerLink]="['/editProfile']">Go to UserLogin</a> 
    
  </div> 
  `, */
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {
  static as: any;
  profile:Profile;
  /* get profile():Profile { 
    return this.capBookService.profile;
  } 
  set profile(profile: Profile) { 
    this.capBookService.profile=profile; 
  }  */
  constructor(private route:ActivatedRoute,private router:Router,private capBookService:CapBookService) { }
  
  ngOnInit() {
    this.profile = JSON.parse(sessionStorage.getItem('profile'));
   }

}
