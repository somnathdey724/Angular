import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {
  addProductTitle:string="Add Product Details";
  _productId:string="";
  _productName:string="";
  _productCode:string="";
  _price:string="";
  _starRating:string="";
  _description:string="";
  _releaseDate:string="";

  constructor() {
    this._productId="";
    this._productName="";
    this._productCode="";
    this._price="";
    this._starRating="";
    this._description="";
    this._releaseDate="";
   }
  get ProductId():string{
    return this._productId;
  }

  set ProductId(value:string){
    this._productId=value;
  }
  get ProductName():string{
    return this._productName;
  }

  set ProductName(value:string){
    this._productName=value;
  }
  get ProductCode():string{
    return this._productCode;
  }

  set ProductCode(value:string){
    this._productCode=value;
  }
  get Price():string{
    return this._price;
  }

  set Price(value:string){
    this._price=value;
  }
  get StarRating():string{
    return this._starRating;
  }

  set StarRating(value:string){
    this._starRating=value;
  }
  get Description():string{
    return this._description;
  }

  set Description(value:string){
    this._description=value;
  }
  get ReleaseDate():string{
    return this._releaseDate;
  }

  set ReleaseDate(value:string){
    this._releaseDate=value;
  }

  ngOnInit() {
  }

}
