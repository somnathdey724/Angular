import { Component, OnInit } from '@angular/core';
import { Product } from './product';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  productListTitle:string="Products List ";
  _listFilter:string="";
  error:string;
  productsList:Product[];
  products:Product[];
  product:Product;

  constructor(private productService:ProductService) { 
    this._listFilter=""
    //this.productsList=this.products;
  }

  ngOnInit() {
    this.productService.getAllProductsDetails().subscribe(
        tempProducts=>{
          this.products=tempProducts;
          this.productsList=this.products;
        }
      ,
        error=>{
          this.error=error;
        }
      );
    this.productService.getProductDetails(111).subscribe(
      tempProduct=>{
        this.product=tempProduct;
      }
    ,
      error=>{
        this.error=error;
      }
    );
  }
  get listFilter():string{
    return this._listFilter;
  }

  set listFilter(value:string){
    this._listFilter=value;
    this.productsList=this.listFilter? this.doProductFilter(this._listFilter): this.products;
  }


  
  // Do product Filtering
  doProductFilter(filterBy:string):Product[]{
    filterBy=filterBy.toLowerCase();
    return this.products.filter(product => product.productName.toLowerCase().indexOf(filterBy)!==-1);
  }

  onRatingClicked(message:string):void{
    this.productListTitle='Products List!!!'+message;
  }
}
