var n=121;
var oldNo;
var newNo=0;
var y;
oldNo=n;
while(n!=0){
    y=(n%10);
    newNo=newNo*10+y;
    n= (Math.floor)( n/10);
}
if(oldNo==newNo)
console.log("Pallindrome Number");
else
console.log("Not a Pallindrome Number");