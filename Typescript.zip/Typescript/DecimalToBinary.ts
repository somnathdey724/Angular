class DecimalToBinary{
    givenNumber:number;
    constructor(givenNumber:number){
        this.givenNumber=givenNumber;
    }
    convertMethod():void{
        var i=0,j,n=0;
        var a=new Array(20);
        while(this.givenNumber!=0){
            if(this.givenNumber%2==0){
            a[i]=0;
            i++;
            }
            else{
                a[i]=1;
                i++;
            }
            this.givenNumber=Math.floor(this.givenNumber/2);
        }
        for(j=i-1;j>0;j--)    
            n=n*10+a[j];
        console.log(n);
    }
    }

console.log(new DecimalToBinary(121).convertMethod());
