var Armstrong = /** @class */ (function () {
    function Armstrong(n) {
        this.n = n;
    }
    Armstrong.prototype.checkArmstrong = function () {
        var reminder;
        var newNo = 0;
        var oldNo = this.n;
        while (this.n != 0) {
            reminder = this.n % 10;
            newNo = newNo + reminder * reminder * reminder;
            this.n = Math.floor(this.n / 10);
        }
        if (newNo == oldNo)
            return "Armstrong Number";
        else
            return "Not a armstrong number";
    };
    return Armstrong;
}());
console.log(new Armstrong(4553).checkArmstrong());
