class Armstrong{
  n:number;
    constructor(n:number){
        this.n=n;
    }
    checkArmstrong():string{
        var reminder;
        var newNo=0;
        var oldNo=this.n;
        while(this.n!=0){
            reminder=this.n%10;
            newNo=newNo+reminder*reminder*reminder;
            this.n=Math.floor(this.n/10);
        }
        if(newNo==oldNo)
        return "Armstrong Number";
        else
        return "Not a armstrong number";
    }
}
console.log(new Armstrong(153).checkArmstrong());