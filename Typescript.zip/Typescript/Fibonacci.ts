class Fibonacci {
    noOfTerms:number;
    constructor(noOfTerms:number){
        this.noOfTerms=noOfTerms;
    }
    fibonacciSeries():void{
        var a=0;
        var b=1;
        var c,i;
        console.log(a);
        console.log(b);
        for(i=0;i<this.noOfTerms;i++){
            c=a+b;
            a=b;
            b=c;
            console.log(c);
        }
    }
}
console.log(new Fibonacci(5).fibonacciSeries());